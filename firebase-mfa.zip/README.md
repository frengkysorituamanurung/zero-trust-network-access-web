<h1 align="center">ZTNA MultiFactor Authentication</h1><br>

## Install the app

```shell
git clone https://github.com/frengkysorituamanurung/zero-trust-network-access-web
```
## Getting Started

First, install dependecies

```shell
yarn install
```

run the development server:

```bash
yarn dev
```

Open your browser to see the result.

## Learn More About Next Js

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js/) - your feedback and contributions are welcome!


