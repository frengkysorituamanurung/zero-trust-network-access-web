"use strict";
exports.id = 259;
exports.ids = [259];
exports.modules = {

/***/ 7348:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BQ": () => (/* binding */ verifyIfUserIsEnrolled),
/* harmony export */   "I8": () => (/* binding */ auth),
/* harmony export */   "NH": () => (/* binding */ verifyUserEmail),
/* harmony export */   "V0": () => (/* binding */ verifyPhoneNumber),
/* harmony export */   "Y$": () => (/* binding */ verifyUserEnrolled),
/* harmony export */   "kS": () => (/* binding */ logout),
/* harmony export */   "n5": () => (/* binding */ verifyUserMFA),
/* harmony export */   "qj": () => (/* binding */ signInWithGoogle),
/* harmony export */   "x4": () => (/* binding */ login),
/* harmony export */   "xh": () => (/* binding */ enrollUser),
/* harmony export */   "y1": () => (/* binding */ signUp)
/* harmony export */ });
/* harmony import */ var _firebase_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61);
/* harmony import */ var _firebase_init__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5876);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_firebase_auth__WEBPACK_IMPORTED_MODULE_0__, _firebase_init__WEBPACK_IMPORTED_MODULE_1__]);
([_firebase_auth__WEBPACK_IMPORTED_MODULE_0__, _firebase_init__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const auth = (0,_firebase_auth__WEBPACK_IMPORTED_MODULE_0__.getAuth)(_firebase_init__WEBPACK_IMPORTED_MODULE_1__/* .app */ .l);
async function signInWithGoogle() {
    try {
        await (0,_firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signInWithPopup)(auth, new _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.GoogleAuthProvider());
        return true;
    } catch (e) {
        return e;
    }
}
async function signUp(email, password) {
    try {
        await (0,_firebase_auth__WEBPACK_IMPORTED_MODULE_0__.createUserWithEmailAndPassword)(auth, email, password);
        return true;
    } catch (e) {
        return false;
    }
}
async function login(email, password) {
    try {
        await (0,_firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signInWithEmailAndPassword)(auth, email, password);
        return true;
    } catch (e) {
        return e;
    }
}
async function logout() {
    try {
        await (0,_firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signOut)(auth);
        return true;
    } catch (e) {
        return false;
    }
}
function verifyIfUserIsEnrolled(user) {
    const enrolledFactors = (0,_firebase_auth__WEBPACK_IMPORTED_MODULE_0__.multiFactor)(user).enrolledFactors;
    return enrolledFactors.length > 0;
}
async function verifyPhoneNumber(user, phoneNumber, recaptchaVerifier) {
    const session = await (0,_firebase_auth__WEBPACK_IMPORTED_MODULE_0__.multiFactor)(user).getSession();
    const phoneInfoOptions = {
        phoneNumber,
        session
    };
    const phoneAuthProvider = new _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.PhoneAuthProvider(auth);
    try {
        return await phoneAuthProvider.verifyPhoneNumber(phoneInfoOptions, recaptchaVerifier);
    } catch (e) {
        return false;
    }
}
async function enrollUser(user, verificationCodeId, verificationCode) {
    const phoneAuthCredential = _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.PhoneAuthProvider.credential(verificationCodeId, verificationCode);
    const multiFactorAssertion = _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.PhoneMultiFactorGenerator.assertion(phoneAuthCredential);
    try {
        await (0,_firebase_auth__WEBPACK_IMPORTED_MODULE_0__.multiFactor)(user).enroll(multiFactorAssertion, "Personal Phone Number");
        return true;
    } catch (e) {
        return false;
    }
}
async function verifyUserMFA(error, recaptchaVerifier, selectedIndex) {
    const resolver = (0,_firebase_auth__WEBPACK_IMPORTED_MODULE_0__.getMultiFactorResolver)(auth, error);
    if (resolver.hints[selectedIndex].factorId === _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.PhoneMultiFactorGenerator.FACTOR_ID) {
        const phoneInfoOptions = {
            multiFactorHint: resolver.hints[selectedIndex],
            session: resolver.session
        };
        const phoneAuthProvider = new _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.PhoneAuthProvider(auth);
        try {
            const verificationId = await phoneAuthProvider.verifyPhoneNumber(phoneInfoOptions, recaptchaVerifier);
            return {
                verificationId,
                resolver
            };
        } catch (e) {
            return false;
        }
    }
}
async function verifyUserEnrolled(verificationMFA, verificationCode) {
    const { verificationId , resolver  } = verificationMFA;
    const credentials = _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.PhoneAuthProvider.credential(verificationId, verificationCode);
    const multiFactorAssertion = _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.PhoneMultiFactorGenerator.assertion(credentials);
    try {
        await resolver.resolveSignIn(multiFactorAssertion);
        return true;
    } catch (e) {
        return false;
    }
}
async function verifyUserEmail(user) {
    try {
        await (0,_firebase_auth__WEBPACK_IMPORTED_MODULE_0__.sendEmailVerification)(user);
        return true;
    } catch (e) {
        return false;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5876:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* binding */ app)
/* harmony export */ });
/* harmony import */ var _firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(72);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_firebase_app__WEBPACK_IMPORTED_MODULE_0__]);
_firebase_app__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyCloOS1H2Rv4bPi5UIu2H2erlfHukjcE50",
    authDomain: "fir-mfa-2aa9c.firebaseapp.com",
    projectId: "fir-mfa-2aa9c",
    storageBucket: "fir-mfa-2aa9c.appspot.com",
    messagingSenderId: "111258049763",
    appId: "1:111258049763:web:a9f27781f2dbf8a87779d6"
};
let app;
if ((0,_firebase_app__WEBPACK_IMPORTED_MODULE_0__.getApps)().length === 0) {
    app = (0,_firebase_app__WEBPACK_IMPORTED_MODULE_0__.initializeApp)(firebaseConfig);
} else {
    app = (0,_firebase_app__WEBPACK_IMPORTED_MODULE_0__.getApp)();
}


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6696:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ notify)
/* harmony export */ });
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6201);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hot_toast__WEBPACK_IMPORTED_MODULE_0__]);
react_hot_toast__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

function notify(message) {
    (0,react_hot_toast__WEBPACK_IMPORTED_MODULE_0__["default"])(message, {
        duration: 5000,
        position: "top-right"
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;