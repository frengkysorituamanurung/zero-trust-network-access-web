"use strict";
exports.id = 167;
exports.ids = [167];
exports.modules = {

/***/ 9464:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "E": () => (/* binding */ Code)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/Input.tsx


function Input({ index , getValue  }) {
    const [value, setValue] = (0,external_react_.useState)("");
    function checkValue(event) {
        const currentValue = event.currentTarget.value.slice(-1);
        setValue(currentValue);
        getValue(currentValue, index);
        const nextElement = event.currentTarget.nextSibling;
        if (nextElement instanceof HTMLInputElement) {
            nextElement.disabled = false;
            nextElement.focus();
        }
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("input", {
        value: value,
        disabled: index > 0,
        onChange: checkValue,
        className: "transition ease-in-out duration-300 flex flex-1 items-center disabled:cursor-not-allowed border-2 outline-none focus:outline-none focus:shadow-[0_0_0_4px_rgba(209,213,218,0.45)] focus:border-2 h-[44px] md:h-[52px] w-full px-4 rounded-xl",
        type: "number"
    });
}

;// CONCATENATED MODULE: ./components/Code.tsx



function Code({ getCode  }) {
    const router = (0,router_.useRouter)();
    let code = new Array(6).fill("");
    function handleClick() {
        const finalCode = code.reduce((previousValue, currentValue)=>{
            return previousValue.concat(currentValue);
        });
        getCode(finalCode);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-white flex flex-col p-5 md:p-6 border-2 border-palladium rounded-xl w-full sm:max-w-[440px]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex justify-between",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "font-medium text-[22px] leading-[130%] md:mr-8",
                            children: "Verify your phone"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-slate-500 mt-2 text-base",
                            children: "We sent you an SMS code to your phone number"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex gap-x-4 mt-6 md:mt-8 pb-4",
                children: code.map((value, index)=>{
                    return /*#__PURE__*/ jsx_runtime_.jsx(Input, {
                        index: index,
                        getValue: (value, index)=>{
                            code[index] = value;
                        }
                    }, index);
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex mt-4 gap-x-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>void router.push("/user"),
                        className: "rounded-xl flex gap-x-4 mb-8 text-black h-11 w-1/2 items-center justify-center px-6 border border-gray-500",
                        children: "Cancel"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: handleClick,
                        className: "bg-black rounded-xl flex h-11 w-1/2 items-center justify-center px-6",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "text-base font-light text-white",
                            children: "Submit"
                        })
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 4805:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useRecaptcha)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61);
/* harmony import */ var _firebase_authentication__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7348);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_firebase_auth__WEBPACK_IMPORTED_MODULE_1__, _firebase_authentication__WEBPACK_IMPORTED_MODULE_2__]);
([_firebase_auth__WEBPACK_IMPORTED_MODULE_1__, _firebase_authentication__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function useRecaptcha(componentId) {
    const [recaptcha, setRecaptcha] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const recaptchaVerifier = new _firebase_auth__WEBPACK_IMPORTED_MODULE_1__.RecaptchaVerifier(componentId, {
            "size": "invisible",
            "callback": ()=>{}
        }, _firebase_authentication__WEBPACK_IMPORTED_MODULE_2__/* .auth */ .I8);
        setRecaptcha(recaptchaVerifier);
        return ()=>{
            recaptchaVerifier.clear();
        };
    }, [
        componentId
    ]);
    return recaptcha;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;